package version

const (
	AppName        = "Melodix"
	AppFullName    = "Melodix Player 2"
	AppDescription = "Discord music bot that allows you to play music from YouTube and internet radio streams."
)

var (
	BuildDate string
	GoVersion string
)
